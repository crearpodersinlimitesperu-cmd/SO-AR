export const usersData = [
  {
    "id": "evelyn.cedillo",
    "name": "Pauly Cedillo",
    "email": "evelyn.cedillo@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "Cuenca"
  },
  {
    "id": "viviana.catota",
    "name": "Mabe Catota",
    "email": "viviana.catota@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "Cuenca"
  },
  {
    "id": "alfonso.trujillo",
    "name": "Joao Trujillo",
    "email": "alfonso.trujillo@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "Cuenca"
  },
  {
    "id": "kerly.carrillo",
    "name": "Kerlie Carrillo",
    "email": "kerly.carrillo@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "Cuenca"
  },
  {
    "id": "juan.reinoso",
    "name": "Juanfer Reinoso",
    "email": "juan.reinoso@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "Cuenca"
  },
  {
    "id": "emely.leon",
    "name": "July Le\u00f3n ",
    "email": "emely.leon@crearpsl.net",
    "role": "gerente",
    "sede": "Cuenca"
  },
  {
    "id": "asistente.facturacion",
    "name": "Alexis Ter\u00e1n",
    "email": "asistente.facturacion@crearpsl.net",
    "role": "finanzas",
    "sede": "Global"
  },
  {
    "id": "diego.flores",
    "name": "Diego Flores",
    "email": "diego.flores@crearpsl.net",
    "role": "finanzas",
    "sede": "Global"
  },
  {
    "id": "asistente.contable",
    "name": "Fernanda Sangoquiza",
    "email": "asistente.contable@crearpsl.net",
    "role": "asistente_impuestos_quito",
    "sede": "Global"
  },
  {
    "id": "paul.sosa",
    "name": "Paul Sosa",
    "email": "paul.sosa@crearpsl.net",
    "role": "direccion",
    "sede": "Global"
  },
  {
    "id": "fer.aragon",
    "name": "Fer Aragon",
    "email": "fer.aragon@crearpsl.net",
    "role": "direccion",
    "sede": "Global"
  },
  {
    "id": "contabilidad.lima",
    "name": "Gabriela  Rivadeneyra",
    "email": "contabilidad.lima@crearpsl.net",
    "role": "finanzas",
    "sede": "Global"
  },
  {
    "id": "contabilidad.medellin",
    "name": "Hector Gonzalez ",
    "email": "contabilidad.medellin@crearpsl.net",
    "role": "finanzas",
    "sede": "Global"
  },
  {
    "id": "andres.gomez",
    "name": "Andres Gomez",
    "email": "andres.gomez@crearpsl.net",
    "role": "coordinador",
    "sede": "Global"
  },
  {
    "id": "coodinacion.administrativa",
    "name": "Karol Villarruel ",
    "email": "coodinacion.administrativa@crearpsl.net",
    "role": "coordinador",
    "sede": "Global"
  },
  {
    "id": "facturacion.cartera",
    "name": "Sebasti\u00e1n J\u00e1come",
    "email": "facturacion.cartera@crearpsl.net",
    "role": "finanzas",
    "sede": "Global"
  },
  {
    "id": "contabilidad.global",
    "name": "Elizabeth Escobar",
    "email": "contabilidad.global@crearpsl.net",
    "role": "finanzas",
    "sede": "Global"
  },
  {
    "id": "leandro.brunis",
    "name": "Leandro Brunis",
    "email": "leandro.brunis@crearpsl.net",
    "role": "direccion",
    "sede": "Global"
  },
  {
    "id": "talento.humano",
    "name": "Lennin Chasi ",
    "email": "talento.humano@crearpsl.net",
    "role": "talento_humano",
    "sede": "Global"
  },
  {
    "id": "legal",
    "name": "Pablo Mendieta",
    "email": "legal@crearpsl.net",
    "role": "legal",
    "sede": "Global"
  },
  {
    "id": "Jonathan.larosa",
    "name": "Jonathan La Rosa",
    "email": "jonathan.larosa@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "Guayaquil"
  },
  {
    "id": "brenda.rodriguez",
    "name": "Brenda Rodr\u00edguez ",
    "email": "brenda.rodriguez@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "Guayaquil"
  },
  {
    "id": "diana.macas",
    "name": "Diana Macas",
    "email": "diana.macas@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "Guayaquil"
  },
  {
    "id": "josue.vera",
    "name": "Josu\u00e9 Vera",
    "email": "josue.vera@crearpsl.net",
    "role": "gerente",
    "sede": "Guayaquil"
  },
  {
    "id": "diana.moscoso",
    "name": "Diana Moscoso Robles",
    "email": "diana.moscoso@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "Lima"
  },
  {
    "id": "joyce.marin",
    "name": "Joyce Mar\u00edn Su\u00e1rez",
    "email": "joyce.marin@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "Lima"
  },
  {
    "id": "linid.valencia",
    "name": "Linid Valencia",
    "email": "linid.valencia@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "Lima"
  },
  {
    "id": "leyla.pasquel",
    "name": "Leyla Pasquel",
    "email": "leyla.pasquel@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "Lima"
  },
  {
    "id": "jose.sanchez",
    "name": "Jos\u00e9 S\u00e1nchez",
    "email": "jose.sanchez@crearpsl.net",
    "role": "gerente",
    "sede": "Lima"
  },
  {
    "id": "valentina.r",
    "name": "Valentina Rodriguez",
    "email": "valentina.r@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "MED"
  },
  {
    "id": "yurany.gonzalez",
    "name": "Yurany G Franco",
    "email": "yurany.gonzalez@crearpsl.net",
    "role": "gerente",
    "sede": "MED"
  },
  {
    "id": "mauricio.ramirez",
    "name": "Mauricio Ramirez",
    "email": "mauricio.ramirez@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "MED"
  },
  {
    "id": "david.gonzalez",
    "name": "David Gonzalez Franco",
    "email": "david.gonzalez@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "MED"
  },
  {
    "id": "naomi.campos",
    "name": "Nao Campos",
    "email": "naomi.campos@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "M\u00e9xico"
  },
  {
    "id": "daniela.monroy",
    "name": "Daniela Monroy ",
    "email": "daniela.monroy@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "M\u00e9xico"
  },
  {
    "id": "nora.zamora",
    "name": "Nora Zamora ",
    "email": "nora.zamora@crearpsl.net",
    "role": "gerente",
    "sede": "M\u00e9xico"
  },
  {
    "id": "adrianna.guarochico",
    "name": "Adrianna Guarochico",
    "email": "adrianna.guarochico@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "UIO"
  },
  {
    "id": "daniela.esposito",
    "name": "Daniela Esposito",
    "email": "daniela.esposito@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "UIO "
  },
  {
    "id": "danna.guaman",
    "name": "Danna Guaman",
    "email": "danna.guaman@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "UIO"
  },
  {
    "id": "emily.campuzano",
    "name": "Emily Campuzano",
    "email": "emily.campuzano@crearpsl.net",
    "role": "gerente",
    "sede": "UIO"
  },
  {
    "id": "erika.gavilanez",
    "name": "Erika Gavil\u00e1nez",
    "email": "erika.gavilanez@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "UIO"
  },
  {
    "id": "freddy.sosa",
    "name": "David Sosa",
    "email": "freddy.sosa@crearpsl.net",
    "role": "gerente",
    "sede": "UIO"
  },
  {
    "id": "ibetancourth",
    "name": "Isaac Betancourth",
    "email": "ibetancourth@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "UIO"
  },
  {
    "id": "judith.romero",
    "name": "Regina Romero",
    "email": "judith.romero@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "UIO"
  },
  {
    "id": "karla.pastrano",
    "name": "Karla Pastrano",
    "email": "karla.pastrano@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "UIO"
  },
  {
    "id": "liliana.cubillo",
    "name": "Lili Cubillo",
    "email": "liliana.cubillo@crearpsl.net",
    "role": "coordinador_mj",
    "sede": "UIO"
  },
  {
    "id": "marco.gonzalez",
    "name": "Adams Gonzalez",
    "email": "marco.gonzalez@crearpsl.net",
    "role": "coordinador_c1c2",
    "sede": "UIO"
  },
  {
    "id": "ketherine.aguirre",
    "name": "Marce Aguirre",
    "email": "ketherine.aguirre@crearpsl.com",
    "role": "coordinador_c1c2",
    "sede": "UIO"
  },
  {
    "id": "sso",
    "name": "Santiago Proa\u00f1o",
    "email": "sso@crearpsl.net",
    "role": "t\u00e9cnico_sst",
    "sede": "UIO"
  }
];
