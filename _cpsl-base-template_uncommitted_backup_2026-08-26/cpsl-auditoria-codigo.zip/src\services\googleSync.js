// src/services/googleSync.js
export const createGoogleTask = async (taskDetails, token) => {
  if (!token) return { success: false, error: 'No token' };
  
  try {
    // Primero obtenemos la lista principal ("@default")
    // Opcionalmente, se podría crear una lista de "CREAR PSL"
    const task = {
      title: taskDetails.title,
      notes: taskDetails.description || '',
      due: taskDetails.dueDate ? new Date(taskDetails.dueDate).toISOString() : undefined,
    };

    const res = await fetch('https://tasks.googleapis.com/tasks/v1/lists/@default/tasks', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(task)
    });

    if (!res.ok) {
      throw new Error(`Google Tasks API Error: ${res.statusText}`);
    }

    const data = await res.json();
    return { success: true, data };
  } catch (error) {
    console.error('Error creando tarea en Google Tasks:', error);
    return { success: false, error: error.message };
  }
};

export const createGoogleEvent = async (eventDetails, token) => {
  if (!token) return { success: false, error: 'No token' };

  try {
    const event = {
      summary: eventDetails.summary,
      location: eventDetails.location || '',
      description: eventDetails.description || '',
      start: {
        dateTime: new Date(eventDetails.start).toISOString(),
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      end: {
        dateTime: new Date(eventDetails.end).toISOString(),
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
    };

    const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(event)
    });

    if (!res.ok) {
      throw new Error(`Google Calendar API Error: ${res.statusText}`);
    }

    const data = await res.json();
    return { success: true, data };
  } catch (error) {
    console.error('Error creando evento en Google Calendar:', error);
    return { success: false, error: error.message };
  }
};
