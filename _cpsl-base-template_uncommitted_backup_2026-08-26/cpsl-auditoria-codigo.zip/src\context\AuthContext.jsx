import { createContext, useContext, useEffect, useState } from 'react';
import { auth } from '../services/firebase';
import { signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged } from 'firebase/auth';
import { usersData } from '../data/usersData';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const loginWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    provider.addScope('https://www.googleapis.com/auth/calendar.events');
    provider.addScope('https://www.googleapis.com/auth/tasks');
    
    try {
      const result = await signInWithPopup(auth, provider);
      
      // Extract Google Access Token for API calls
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential && credential.accessToken) {
        localStorage.setItem('googleAccessToken', credential.accessToken);
      }
      
      const user = result.user;
      const normalizedEmail = user.email.trim().toLowerCase();
      
      const foundUser = usersData.find(u => u.email.toLowerCase() === normalizedEmail);
      if (!foundUser) {
        await auth.signOut();
        alert('ACCESO DENEGADO: Tu correo no se encuentra en el Directorio Global. Contacta a Gerencia.');
        throw new Error('Unauthorized');
      }

      // Merge role info into the currentUser object
      setCurrentUser({
        ...user,
        appRole: foundUser.role,
        sede: foundUser.sede
      });
      return user;
    } catch (error) {
      console.error("Error signing in with Google", error);
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('googleAccessToken');
    return signOut(auth);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, user => {
      if (user) {
        const normalizedEmail = user.email.trim().toLowerCase();
        const foundUser = usersData.find(u => u.email.toLowerCase() === normalizedEmail);
        
        if (foundUser) {
          setCurrentUser({
            ...user,
            appRole: foundUser.role,
            sede: foundUser.sede
          });
        } else {
          localStorage.removeItem('googleAccessToken');
          auth.signOut();
          setCurrentUser(null);
        }
      } else {
        setCurrentUser(null);
      }
      setLoading(false);
    });
    
    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider value={{ currentUser, loginWithGoogle, logout, loading }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
