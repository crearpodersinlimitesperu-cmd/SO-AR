import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '../services/firebase';
import { collection, onSnapshot, addDoc, updateDoc, doc, query, orderBy, writeBatch } from 'firebase/firestore';
import { useAuth } from '../context/AuthContext';
import { useCycles } from '../context/CyclesContext';
import { ArrowLeft, Target, Settings, GitMerge } from 'lucide-react';

export default function GoalsBoard() {
  const { currentUser } = useAuth();
  const { currentCycle } = useCycles();
  const navigate = useNavigate();
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);

  // Wizard State
  const [showWizard, setShowWizard] = useState(false);
  const [wizardStep, setWizardStep] = useState(0);
  
  const stages = [
    { id: 'C1', name: 'Capítulo 1' },
    { id: 'C2', name: 'Capítulo 2' },
    { id: 'MJ_CREACION', name: 'MJ - Creación' },
    { id: 'MJ_RELACION', name: 'MJ - Relación' },
    { id: 'MJ_GRATITUD', name: 'MJ - Gratitud' },
    { id: 'MJ_VIAJE', name: 'MJ - El Viaje' }
  ];

  // Estructura para guardar las metas del wizard
  const [wizardData, setWizardData] = useState(
    stages.reduce((acc, stage) => {
      acc[stage.id] = { px: '', aliados: '', managers: '' };
      return acc;
    }, {})
  );

  useEffect(() => {
    const goalsRef = collection(db, 'goals');
    const q = query(goalsRef, orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const loadedGoals = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setGoals(loadedGoals);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleWizardChange = (stageId, field, value) => {
    setWizardData(prev => ({
      ...prev,
      [stageId]: { ...prev[stageId], [field]: value }
    }));
  };

  const handleGenerateGoals = async () => {
    try {
      const batch = writeBatch(db);
      const cycleGoalRef = doc(collection(db, 'goals'));
      
      // 1. Crear Meta Maestra del Ciclo
      batch.set(cycleGoalRef, {
        title: `Meta Global del Ciclo ${currentCycle?.name || ''}`,
        kpi: 'Cumplimiento General (%)',
        progress: 0,
        targetValue: 100, // Meta abstracta de ciclo se mide en % general
        currentValue: 0,
        scope: 'CICLO',
        parentId: null,
        ownerId: currentUser.uid,
        ownerName: currentUser.displayName,
        createdAt: new Date().toISOString()
      });

      // 2. Crear las metas de ENTRENAMIENTO basadas en el Wizard
      for (const stage of stages) {
        const data = wizardData[stage.id];
        
        if (data.px && Number(data.px) > 0) {
          batch.set(doc(collection(db, 'goals')), {
             title: `Sentados (Px) - ${stage.name}`,
             kpi: 'Cantidad de Px',
             targetValue: Number(data.px),
             currentValue: 0,
             progress: 0,
             scope: 'ENTRENAMIENTO',
             parentId: cycleGoalRef.id,
             stage: stage.id,
             ownerId: currentUser.uid,
             createdAt: new Date().toISOString()
          });
        }
        if (data.aliados && Number(data.aliados) > 0) {
          batch.set(doc(collection(db, 'goals')), {
             title: `Aliados - ${stage.name}`,
             kpi: 'Cantidad de Aliados',
             targetValue: Number(data.aliados),
             currentValue: 0,
             progress: 0,
             scope: 'ENTRENAMIENTO',
             parentId: cycleGoalRef.id,
             stage: stage.id,
             ownerId: currentUser.uid,
             createdAt: new Date().toISOString()
          });
        }
        if (data.managers && Number(data.managers) > 0) {
          batch.set(doc(collection(db, 'goals')), {
             title: `Managers - ${stage.name}`,
             kpi: 'Cantidad de Managers',
             targetValue: Number(data.managers),
             currentValue: 0,
             progress: 0,
             scope: 'ENTRENAMIENTO',
             parentId: cycleGoalRef.id,
             stage: stage.id,
             ownerId: currentUser.uid,
             createdAt: new Date().toISOString()
          });
        }
      }

      await batch.commit();
      alert('Metas de Ciclo generadas correctamente.');
      setShowWizard(false);
    } catch (e) {
      console.error(e);
      alert('Error generando metas.');
    }
  };

  const updateProgress = async (id, currentVal, targetVal) => {
    const newVal = prompt(`Ingresa nuevo valor acumulado (Meta: ${targetVal}):`, currentVal);
    if (newVal !== null && !isNaN(newVal)) {
      try {
        const numericVal = Number(newVal);
        const newProgress = Math.round((numericVal / targetVal) * 100);
        
        await updateDoc(doc(db, 'goals', id), { 
          currentValue: numericVal,
          progress: Math.min(newProgress, 100)
        });
        
        // Roll-up logic (Promedio a metas padre)
        const currentGoal = goals.find(g => g.id === id);
        if (currentGoal && currentGoal.parentId) {
          const siblings = goals.filter(g => g.parentId === currentGoal.parentId && g.id !== id);
          
          let totalProgress = newProgress;
          siblings.forEach(s => totalProgress += (s.progress || 0));
          const avgProgress = Math.round(totalProgress / (siblings.length + 1));
          
          await updateDoc(doc(db, 'goals', currentGoal.parentId), { progress: avgProgress });
          
          // Doble Roll-up
          const parentGoal = goals.find(g => g.id === currentGoal.parentId);
          if (parentGoal && parentGoal.parentId) {
             const parentSiblings = goals.filter(g => g.parentId === parentGoal.parentId && g.id !== parentGoal.id);
             let parentTotal = avgProgress;
             parentSiblings.forEach(s => parentTotal += (s.progress || 0));
             const parentAvg = Math.round(parentTotal / (parentSiblings.length + 1));
             await updateDoc(doc(db, 'goals', parentGoal.parentId), { progress: parentAvg });
          }
        }
      } catch (e) {
        console.error("Error actualizando meta:", e);
        alert('Error actualizando meta');
      }
    }
  };

  const renderGoal = (goal) => {
    const parentGoal = goals.find(g => g.id === goal.parentId);
    
    return (
      <div key={goal.id} className="glass-panel" style={{ padding: '1.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <span style={{ 
                fontSize: '0.7rem', fontWeight: 'bold', padding: '0.2rem 0.5rem', borderRadius: '4px',
                background: goal.scope === 'CICLO' ? 'var(--crear-gold)' : goal.scope === 'ENTRENAMIENTO' ? 'var(--crear-blue)' : 'var(--color-success)',
                color: '#000', letterSpacing: '1px'
              }}>
                {goal.scope}
              </span>
              {parentGoal && (
                <span className="text-muted" style={{ fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                  <GitMerge size={12} /> Aporta a: {parentGoal.title}
                </span>
              )}
            </div>
            <h3 className="text-main" style={{ margin: '0 0 0.5rem 0' }}>{goal.title}</h3>
            <p className="text-muted" style={{ margin: 0, fontSize: '0.9rem' }}>
              {goal.targetValue ? `Avance: ${goal.currentValue || 0} de ${goal.targetValue}` : `KPI: ${goal.kpi}`}
            </p>
          </div>
          {goal.targetValue && (
            <button className="btn-secondary" onClick={() => updateProgress(goal.id, goal.currentValue, goal.targetValue)} style={{ padding: '0.5rem 1rem', height: 'fit-content' }}>
              Actualizar Valor
            </button>
          )}
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{ flex: 1, height: '12px', background: 'rgba(255,255,255,0.05)', borderRadius: '6px', overflow: 'hidden' }}>
            <div style={{ height: '100%', width: `${Math.min(goal.progress, 100)}%`, background: goal.progress >= 100 ? 'var(--color-success)' : 'var(--crear-blue)', transition: 'width 0.3s ease' }} />
          </div>
          <span className="text-gold" style={{ fontWeight: 'bold', minWidth: '40px' }}>{goal.progress}%</span>
        </div>
      </div>
    );
  };

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem 1rem' }}>
      <button onClick={() => navigate('/')} className="btn-secondary" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1rem' }}>
        <ArrowLeft size={18} /> Volver
      </button>

      <div className="glass-panel" style={{ padding: '2rem', marginBottom: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <Target size={32} className="text-gold" />
          <div>
            <h1 className="text-gold uppercase" style={{ margin: 0 }}>Gestión de Metas</h1>
            <p className="text-muted" style={{ margin: 0, fontSize: '0.9rem' }}>Seguimiento y acumulación operativa</p>
          </div>
        </div>
        {currentUser?.appRole === 'gerente' && (
          <button className="btn-primary" onClick={() => setShowWizard(true)} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.8rem 1.5rem' }}>
            <Settings size={18} /> Setup de Ciclo
          </button>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '1.5rem' }}>
        {loading ? <p className="text-muted text-center">Cargando metas...</p> : (
          goals.length > 0 ? goals.map(renderGoal) : <p className="text-muted" style={{ textAlign: 'center' }}>No hay metas configuradas. Inicia el Setup de Ciclo.</p>
        )}
      </div>

      {showWizard && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', justifyContent: 'center', alignItems: 'flex-start', zIndex: 100, overflowY: 'auto', padding: '2rem 0' }}>
          <div className="glass-panel" style={{ padding: '2rem', width: '90%', maxWidth: '600px', margin: 'auto' }}>
            <h2 className="text-gold" style={{ marginTop: 0, borderBottom: '1px solid rgba(255,215,0,0.2)', paddingBottom: '1rem' }}>
              Configuración Maestra: {stages[wizardStep].name}
            </h2>
            <p className="text-muted" style={{ marginBottom: '2rem' }}>Define los números objetivo (Sentados) para este entrenamiento.</p>
            
            <div style={{ display: 'grid', gap: '1.5rem', marginBottom: '2rem' }}>
              <div>
                <label className="text-white" style={{ display: 'block', marginBottom: '0.5rem' }}>Meta de Participantes (Px):</label>
                <input 
                  type="number" 
                  value={wizardData[stages[wizardStep].id].px}
                  onChange={e => handleWizardChange(stages[wizardStep].id, 'px', e.target.value)}
                  style={{ width: '100%', padding: '0.8rem', background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.1)', color: 'white', borderRadius: '4px' }}
                  placeholder="Ej. 100"
                />
              </div>
              <div>
                <label className="text-white" style={{ display: 'block', marginBottom: '0.5rem' }}>Meta de Aliados requeridos:</label>
                <input 
                  type="number" 
                  value={wizardData[stages[wizardStep].id].aliados}
                  onChange={e => handleWizardChange(stages[wizardStep].id, 'aliados', e.target.value)}
                  style={{ width: '100%', padding: '0.8rem', background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.1)', color: 'white', borderRadius: '4px' }}
                  placeholder="Ej. 20"
                />
              </div>
              <div>
                <label className="text-white" style={{ display: 'block', marginBottom: '0.5rem' }}>Meta de Managers requeridos:</label>
                <input 
                  type="number" 
                  value={wizardData[stages[wizardStep].id].managers}
                  onChange={e => handleWizardChange(stages[wizardStep].id, 'managers', e.target.value)}
                  style={{ width: '100%', padding: '0.8rem', background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.1)', color: 'white', borderRadius: '4px' }}
                  placeholder="Ej. 5"
                />
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '1rem' }}>
              <button className="btn-secondary" onClick={() => setShowWizard(false)}>Cancelar</button>
              
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                {wizardStep > 0 && (
                  <button className="btn-secondary" onClick={() => setWizardStep(prev => prev - 1)}>Atrás</button>
                )}
                {wizardStep < stages.length - 1 ? (
                  <button className="btn-primary" onClick={() => setWizardStep(prev => prev + 1)}>Siguiente</button>
                ) : (
                  <button className="btn-primary" onClick={handleGenerateGoals} style={{ background: 'var(--color-success)', borderColor: 'var(--color-success)' }}>Finalizar y Crear</button>
                )}
              </div>
            </div>
            
            {/* Indicador de pasos */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem', marginTop: '2rem' }}>
              {stages.map((_, i) => (
                <div key={i} style={{ width: '10px', height: '10px', borderRadius: '50%', background: i === wizardStep ? 'var(--crear-gold)' : 'rgba(255,255,255,0.2)' }} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
