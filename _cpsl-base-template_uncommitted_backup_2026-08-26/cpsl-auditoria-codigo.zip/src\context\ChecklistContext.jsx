import { createContext, useContext, useState, useEffect } from 'react';
import { db } from '../services/firebase';
import { collection, onSnapshot, doc, updateDoc, writeBatch } from 'firebase/firestore';
import { checklistData } from '../data/checklistData';
import { createGoogleTask } from '../services/googleSync';

const ChecklistContext = createContext();

export function ChecklistProvider({ children }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Escuchar cambios en la colección "tasks" en tiempo real
    const tasksRef = collection(db, 'tasks');
    const unsubscribe = onSnapshot(tasksRef, (snapshot) => {
      if (snapshot.empty) {
        // Si está vacía, podríamos inicializarla, pero por ahora solo seteamos vacío
        setTasks([]);
      } else {
        const loadedTasks = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        setTasks(loadedTasks);
      }
      setLoading(false);
    }, (error) => {
      console.error("Error fetching tasks from Firestore:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const toggleTask = async (taskId, currentStatus) => {
    try {
      const taskRef = doc(db, 'tasks', taskId);
      await updateDoc(taskRef, {
        completed: !currentStatus,
        status: !currentStatus ? 'Completada' : 'Pendiente'
      });
    } catch (error) {
      console.error("Error updating task:", error);
      alert("No se pudo actualizar la tarea. Revisa los permisos de Firestore.");
    }
  };

  const updateTaskDetails = async (taskId, updates) => {
    try {
      const taskRef = doc(db, 'tasks', taskId);
      await updateDoc(taskRef, updates);
    } catch (error) {
      console.error("Error updating task details:", error);
      alert("No se pudo actualizar la tarea.");
    }
  };

  const addCustomTask = async (taskData) => {
    try {
      const batch = writeBatch(db);
      // Creamos un ID único usando timestamp
      const customId = `custom_${Date.now()}`;
      const taskRef = doc(db, 'tasks', customId);
      
      batch.set(taskRef, {
        id: customId,
        ...taskData,
        completed: false,
        status: 'Pendiente',
        created_at: new Date().toISOString()
      });
      await batch.commit();
      return true;
    } catch (error) {
      console.error("Error creating custom task:", error);
      alert("No se pudo crear la tarea. Revisa los permisos de Firestore.");
      return false;
    }
  };

  const submitEvidence = async (taskId, evidenceUrl) => {
    try {
      const taskRef = doc(db, 'tasks', taskId);
      await updateDoc(taskRef, {
        status: 'Pendiente de validación',
        evidence_url: evidenceUrl,
        date: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error submitting evidence:", error);
      alert("No se pudo enviar la evidencia.");
    }
  };

  const getProgressByRole = (roleId) => {
    const roleTasks = tasks.filter(t => t.role === roleId);
    if (roleTasks.length === 0) return 0;
    const completed = roleTasks.filter(t => t.completed).length;
    return Math.round((completed / roleTasks.length) * 100);
  };

  // Función de utilidad para cargar las tareas iniciales a Firestore (Solo la usa el Gerente una vez)
  const initializeFirestore = async () => {
    const confirm = window.confirm("¡ADVERTENCIA! Esto borrará todas las tareas actuales e inyectará la estructura maestra del SO-AR. ¿Estás seguro?");
    if (!confirm) return;
    
    try {
      const batch = writeBatch(db);
      checklistData.forEach(task => {
        const taskRef = doc(db, 'tasks', task.id);
        batch.set(taskRef, { 
          ...task, 
          completed: false,
          status: 'Pendiente',
          priority: '🟡 AMARILLO', // Por defecto
          progressPercentage: 0,
          created_at: new Date().toISOString()
        });
      });
      await batch.commit();
      alert("¡Base de datos SO-AR inicializada correctamente!");
    } catch (error) {
      console.error("Error initializing DB:", error);
      alert("Error al inicializar. ¿Cambiaste las reglas de Firestore a true?");
    }
  };

  const syncTasksToGoogle = async (roleId) => {
    const token = localStorage.getItem('googleAccessToken');
    if (!token) {
      alert("No se encontró sesión con permisos de Google. Por favor, cierra sesión y vuelve a entrar.");
      return;
    }

    // Buscamos tareas para este rol que NO estén completadas ni sincronizadas
    const myUnsyncedTasks = tasks.filter(t => t.role === roleId && !t.completed && !t.googleSynced);
    if (myUnsyncedTasks.length === 0) {
      alert("No tienes tareas pendientes por sincronizar a Google.");
      return;
    }

    let successCount = 0;
    for (let task of myUnsyncedTasks) {
      const result = await createGoogleTask({
        title: task.title,
        description: task.description || '',
        dueDate: task.dueDate || undefined
      }, token);

      if (result.success) {
        // Actualizamos en Firestore para no volverla a sincronizar
        try {
          const taskRef = doc(db, 'tasks', task.id);
          await updateDoc(taskRef, { googleSynced: true });
          successCount++;
        } catch (e) {
          console.error("Error marcando tarea como sincronizada:", e);
        }
      }
    }

    alert(`¡Se sincronizaron ${successCount} tareas a tu cuenta de Google Tasks exitosamente!`);
  };

  return (
    <ChecklistContext.Provider value={{ tasks, toggleTask, updateTaskDetails, submitEvidence, getProgressByRole, loading, initializeFirestore, addCustomTask, syncTasksToGoogle }}>
      {children}
    </ChecklistContext.Provider>
  );
}

export function useChecklist() {
  return useContext(ChecklistContext);
}
