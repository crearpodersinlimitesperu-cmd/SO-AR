import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useChecklist } from '../context/ChecklistContext';
import { useCycles } from '../context/CyclesContext';
import { roles } from '../data/checklistData';
import { ArrowLeft, Target, Link as LinkIcon, Edit3, Filter } from 'lucide-react';

export default function ChecklistBoard() {
  const { roleId } = useParams();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { tasks, toggleTask, updateTaskDetails } = useChecklist();
  const { currentStage } = useCycles();

  const role = roles.find(r => r.id === roleId);
  const myTasks = tasks.filter(t => t.role === roleId);

  const filterParam = searchParams.get('filter');

  let activeTasks = myTasks;
  let viewTitle = `Checklist SO-AR Activo: ${currentStage}`;

  if (filterParam === 'completed') {
    activeTasks = myTasks.filter(t => t.completed || t.status === 'Completada');
    viewTitle = "Mostrando: Tareas Completadas";
  } else if (filterParam === 'criticas') {
    activeTasks = myTasks.filter(t => !t.completed && (t.isCritical || t.priority === '🔴 ROJO'));
    viewTitle = "Mostrando: Tareas Críticas (Urgentes)";
  } else if (filterParam === 'importantes') {
    activeTasks = myTasks.filter(t => !t.completed && !t.isCritical && t.priority !== '🔴 ROJO');
    viewTitle = "Mostrando: Tareas Importantes";
  } else {
    // Vista Normal del Checklist Activo
    activeTasks = myTasks.filter(t => 
      (t.cyclePhase === currentStage) || (t.associatedGoal && !t.completed) || (t.isCritical && !t.completed)
    );
  }

  if (!role) {
    return <div className="text-gold" style={{ padding: '2rem', textAlign: 'center' }}>Rol no encontrado</div>;
  }

  // El progreso siempre es de mis tareas totales de la fase, no de la vista filtrada
  const stageTasks = myTasks.filter(t => t.cyclePhase === currentStage || t.associatedGoal);
  const completedActive = stageTasks.filter(t => t.completed || t.status === 'Completada').length;
  const progress = stageTasks.length > 0 ? Math.round((completedActive / stageTasks.length) * 100) : 100;

  const handleStatusChange = (task) => {
    toggleTask(task.id, task.completed);
  };

  const handleAddEvidence = (task) => {
    const url = prompt("Introduce el link de la evidencia (Google Drive, Docs, etc):", task.evidenceUrl || "");
    if (url !== null) {
      updateTaskDetails(task.id, { evidenceUrl: url });
    }
  };

  const handleAddComment = (task) => {
    const comment = prompt("Añadir comentario u observación:", task.comments || "");
    if (comment !== null) {
      updateTaskDetails(task.id, { comments: comment });
    }
  };

  const handleProgressChange = (task) => {
    const p = prompt("Actualizar porcentaje de avance (0-100):", task.progressPercentage || 0);
    if (p !== null && !isNaN(p)) {
      updateTaskDetails(task.id, { progressPercentage: Math.min(100, Math.max(0, parseInt(p))) });
    }
  };

  const getPriorityColor = (priorityStr) => {
    if (!priorityStr) return 'var(--text-muted)';
    if (priorityStr.includes('ROJO')) return '#ef4444';
    if (priorityStr.includes('AMARILLO')) return '#f59e0b';
    if (priorityStr.includes('VERDE')) return '#22c55e';
    return 'var(--text-muted)';
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '2rem 1rem' }}>
      <button onClick={() => navigate(-1)} className="btn-secondary" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1rem' }}>
        <ArrowLeft size={18} /> Volver
      </button>

      <div className="glass-panel" style={{ padding: '2rem', marginBottom: '2rem' }}>
        <h1 className="text-gold uppercase" style={{ fontSize: '1.8rem', margin: '0 0 0.5rem 0' }}>{role.name}</h1>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <p className={filterParam ? "text-blue" : "text-muted"} style={{ margin: 0, fontWeight: filterParam ? 'bold' : 'normal' }}>
            {viewTitle}
          </p>
          {filterParam && (
            <button onClick={() => setSearchParams({})} style={{ background: 'none', border: '1px solid rgba(255,255,255,0.2)', color: 'var(--text-muted)', padding: '0.3rem 0.8rem', borderRadius: '4px', fontSize: '0.8rem', cursor: 'pointer' }}>
              Limpiar Filtro
            </button>
          )}
        </div>
        
        <div style={{ width: '100%', height: '8px', background: 'rgba(255,255,255,0.1)', borderRadius: '4px', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${progress}%`, background: progress === 100 ? 'var(--color-success)' : 'var(--crear-gold)', transition: 'width 0.4s ease' }} />
        </div>
        <p className="text-gold" style={{ marginTop: '0.5rem', fontWeight: 'bold' }}>{progress}% Completado en esta Fase</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        {activeTasks.length === 0 ? (
          <p className="text-muted text-center" style={{ margin: '2rem 0' }}>No hay tareas para esta fase del ciclo operativo.</p>
        ) : (
          activeTasks.map(task => (
            <div key={task.id} className="glass-panel hover-glow" style={{ padding: '1.5rem', borderLeft: `4px solid ${getPriorityColor(task.priority)}`, opacity: task.completed ? 0.6 : 1, transition: 'all 0.3s' }}>
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem' }}>
                <div style={{ flex: 1, display: 'flex', gap: '1rem' }}>
                  <input 
                    type="checkbox" 
                    checked={task.completed || task.status === 'Completada'}
                    onChange={() => handleStatusChange(task)}
                    style={{ width: '20px', height: '20px', cursor: 'pointer', marginTop: '3px' }}
                  />
                  <div>
                    <h3 className={task.completed ? 'text-muted' : 'text-white'} style={{ margin: '0 0 0.5rem 0', textDecoration: task.completed ? 'line-through' : 'none' }}>
                      {task.task || task.title}
                    </h3>
                    
                    {task.associatedGoal && (
                      <div style={{ background: 'rgba(41, 171, 226, 0.1)', border: '1px solid rgba(41, 171, 226, 0.3)', padding: '0.5rem', borderRadius: '4px', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem' }}>
                        <Target size={14} className="text-blue" />
                        <span className="text-blue"><strong>Meta Asociada:</strong> {task.associatedGoal}</span>
                        {task.deadline && <span className="text-muted" style={{ marginLeft: 'auto' }}>Límite: {task.deadline}</span>}
                      </div>
                    )}

                    {(task.comments || task.evidenceUrl) && (
                      <div style={{ marginTop: '0.8rem', padding: '0.8rem', background: 'rgba(0,0,0,0.2)', borderRadius: '6px', fontSize: '0.85rem' }}>
                        {task.comments && <p className="text-muted" style={{ margin: '0 0 0.5rem 0' }}>💬 {task.comments}</p>}
                        {task.evidenceUrl && <a href={task.evidenceUrl} target="_blank" rel="noreferrer" className="text-gold" style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', textDecoration: 'none' }}><LinkIcon size={12}/> Evidencia Adjunta</a>}
                      </div>
                    )}
                  </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', alignItems: 'flex-end', minWidth: '120px' }}>
                  {task.priority && (
                    <span style={{ fontSize: '0.75rem', fontWeight: 'bold', padding: '0.2rem 0.5rem', borderRadius: '12px', background: 'rgba(255,255,255,0.05)', color: getPriorityColor(task.priority) }}>
                      {task.priority}
                    </span>
                  )}
                  {task.progressPercentage !== undefined && (
                    <span className="text-muted" style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>
                      Avance: {task.progressPercentage}%
                    </span>
                  )}
                </div>
              </div>

              {/* Botones de Acción */}
              {!task.completed && (
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem', marginLeft: '36px', flexWrap: 'wrap' }}>
                  <button onClick={() => handleAddComment(task)} style={{ background: 'none', border: '1px solid rgba(255,255,255,0.2)', color: 'var(--text-muted)', padding: '0.3rem 0.8rem', borderRadius: '4px', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.3rem', cursor: 'pointer' }}>
                    <Edit3 size={14} /> Notas
                  </button>
                  <button onClick={() => handleAddEvidence(task)} style={{ background: 'none', border: '1px solid rgba(255,255,255,0.2)', color: 'var(--text-muted)', padding: '0.3rem 0.8rem', borderRadius: '4px', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.3rem', cursor: 'pointer' }}>
                    <LinkIcon size={14} /> Evidencia
                  </button>
                  <button onClick={() => handleProgressChange(task)} style={{ background: 'none', border: '1px solid rgba(255,255,255,0.2)', color: 'var(--text-muted)', padding: '0.3rem 0.8rem', borderRadius: '4px', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.3rem', cursor: 'pointer' }}>
                    % Avance
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
