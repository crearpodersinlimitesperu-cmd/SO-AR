import React from 'react';

export const getFlagForSede = (sede) => {
  if (!sede) return '🌎';
  const s = sede.toLowerCase();
  
  const style = { display: 'inline-block', width: '16px', height: '11px', borderRadius: '2px', marginLeft: '4px', marginRight: '4px' };

  if (s.includes('ecuador') || s.includes('uio') || s.includes('quito') || s.includes('guayaquil') || s.includes('gye') || s.includes('cuenca') || s.includes('cue')) {
    return <img src="https://flagcdn.com/w20/ec.png" alt="EC" style={style} />;
  }
  if (s.includes('lima') || s.includes('lim') || s.includes('peru') || s.includes('perú')) {
    return <img src="https://flagcdn.com/w20/pe.png" alt="PE" style={style} />;
  }
  if (s.includes('colombia') || s.includes('med') || s.includes('medellin') || s.includes('medellín') || s.includes('bogota') || s.includes('bogotá')) {
    return <img src="https://flagcdn.com/w20/co.png" alt="CO" style={style} />;
  }
  if (s.includes('mexico') || s.includes('mex') || s.includes('mx') || s.includes('méxico')) {
    return <img src="https://flagcdn.com/w20/mx.png" alt="MX" style={style} />;
  }
  
  return '🌎'; // Por defecto o Global
};
