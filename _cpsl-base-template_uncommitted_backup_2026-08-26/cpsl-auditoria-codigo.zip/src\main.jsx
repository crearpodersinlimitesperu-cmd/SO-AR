import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import './index.css'
import { ChecklistProvider } from './context/ChecklistContext'
import { AuthProvider } from './context/AuthContext'
import { CyclesProvider } from './context/CyclesContext'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <CyclesProvider>
          <ChecklistProvider>
            <App />
          </ChecklistProvider>
        </CyclesProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
)
