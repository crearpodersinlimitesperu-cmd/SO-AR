import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useCycles } from '../context/CyclesContext';
import { useChecklist } from '../context/ChecklistContext';
import { useNavigate } from 'react-router-dom';
import { Target, AlertTriangle, Users, PlusCircle, Activity, CheckCircle } from 'lucide-react';

export default function GerenteDashboard() {
  const { currentUser } = useAuth();
  const { currentStage } = useCycles();
  const { tasks, addCustomTask, initializeFirestore, getProgressByRole } = useChecklist();
  const navigate = useNavigate();

  const [showTaskForm, setShowTaskForm] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    role: 'coord_c1',
    deadline: '',
    expectedResult: '',
    followUp: '',
    associatedGoal: ''
  });

  useEffect(() => {
    if (currentUser?.appRole !== 'gerente') {
      navigate('/');
    }
  }, [currentUser, navigate]);

  const handleAssignTask = async (e) => {
    e.preventDefault();
    if (!newTask.title || !newTask.role) {
      alert("Debes indicar un rol y el título de la tarea.");
      return;
    }
    
    // Convertir el formato del Gerente al formato interno
    const success = await addCustomTask({
      task: newTask.title,
      role: newTask.role,
      deadline: newTask.deadline,
      expectedResult: newTask.expectedResult,
      followUp: newTask.followUp,
      associatedGoal: newTask.associatedGoal,
      cyclePhase: currentStage,
      priority: '🔴 ROJO', // Meta explícita entra como prioridad alta
      status: 'Pendiente',
      isCritical: true
    });
    
    if (success) {
      alert("¡Meta/Tarea asignada con éxito al Coordinador!");
      setShowTaskForm(false);
      setNewTask({ title: '', role: 'coord_c1', deadline: '', expectedResult: '', followUp: '', associatedGoal: '' });
    }
  };

  // --- DERIVED DATA ---
  
  // 1. & 2. Entrenamientos
  const currentTraining = currentStage;
  const nextTraining = currentStage === 'PRE-C1' ? 'C1' : 
                       currentStage === 'C1' ? 'C2' : 
                       currentStage === 'C2' ? 'Maestría del Juego' : 'Próximo Ciclo';

  // 3. Confirmaciones de esta semana (Tareas de Gerente pendientes de la fase actual)
  const myPendingTasks = tasks.filter(t => t.role === 'gerente' && !t.completed && t.cyclePhase === currentStage);
  
  // 4. & 5. Metas Principales y Responsables (Custom Tasks asigned by Gerente)
  const assignedGoals = tasks.filter(t => t.associatedGoal && !t.completed);

  // 6. Atrasado o en Riesgo (Todas las tareas con prioridad Roja que no estén completadas)
  const atRiskTasks = tasks.filter(t => !t.completed && t.priority === '🔴 ROJO');

  // 7. Intervención Gerencial (Tareas escaladas, si las hubiera, o tareas de gerente marcadas rojas)
  const managerIntervention = myPendingTasks.filter(t => t.priority === '🔴 ROJO' || t.isCritical);

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem 1rem' }}>
      
      {/* HEADER */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 className="text-gold" style={{ margin: 0, fontSize: '2rem' }}>Tablero Diario del Gerente</h1>
          <p className="text-muted" style={{ margin: '0.5rem 0 0', textTransform: 'uppercase' }}>
            {new Date().toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <button className="btn-secondary" onClick={initializeFirestore} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', border: '1px solid #ef4444', color: '#ef4444' }}>
            ⚠ Inyectar SO-AR DB
          </button>
          <button className="btn-primary" onClick={() => setShowTaskForm(!showTaskForm)} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <PlusCircle size={18} /> Asignar Meta / Tarea
          </button>
          <button className="btn-secondary" onClick={() => navigate('/')}>Volver al Inicio</button>
        </div>
      </div>

      {showTaskForm && (
        <div className="glass-panel" style={{ padding: '2rem', marginBottom: '2rem', border: '1px solid var(--crear-gold)' }}>
          <h3 className="text-gold" style={{ marginTop: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Target size={20} /> Asignación de Meta Oficial
          </h3>
          <p className="text-muted text-sm" style={{ marginBottom: '1.5rem' }}>Toda meta debe contener obligatoriamente estos parámetros (Regla #17 del SO-AR).</p>
          <form onSubmit={handleAssignTask} style={{ display: 'grid', gap: '1rem' }}>
            <input type="text" placeholder="META (Ej. Sentar 25 rezagados de C1)" value={newTask.title} onChange={e => setNewTask({...newTask, title: e.target.value})} className="input-field" required />
            
            <div style={{ display: 'flex', gap: '1rem' }}>
              <select value={newTask.role} onChange={e => setNewTask({...newTask, role: e.target.value})} className="input-field" style={{ flex: 1 }}>
                <option value="coord_c1">Coordinador C1/C2</option>
                <option value="coord_maestria">Coordinador Maestría</option>
                <option value="capitan">Capitán</option>
              </select>
              <input type="date" value={newTask.deadline} onChange={e => setNewTask({...newTask, deadline: e.target.value})} className="input-field" style={{ flex: 1 }} required />
            </div>

            <input type="text" placeholder="RESULTADO ESPERADO (Ej. 25 personas sentadas)" value={newTask.expectedResult} onChange={e => setNewTask({...newTask, expectedResult: e.target.value})} className="input-field" required />
            
            <input type="text" placeholder="SEGUIMIENTO (Ej. Revisión Semanal)" value={newTask.followUp} onChange={e => setNewTask({...newTask, followUp: e.target.value})} className="input-field" required />

            <button type="submit" className="btn-primary" style={{ background: 'var(--crear-gold)', color: 'black', marginTop: '1rem' }}>
              Confirmar Meta
            </button>
          </form>
        </div>
      )}

      {/* AVANCE DEL EQUIPO */}
      <div className="glass-panel" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
        <h3 className="text-gold" style={{ marginTop: 0, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem', borderBottom: '1px solid rgba(255,215,0,0.2)', paddingBottom: '0.5rem' }}>
          <Users size={20} /> AVANCE OPERATIVO DEL EQUIPO
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem' }}>
          {[
            { id: 'coord_c1', name: 'Coordinador C1/C2' },
            { id: 'coord_maestria', name: 'Coordinador Maestría' },
            { id: 'capitan', name: 'Capitán' },
            { id: 'qt', name: 'Quantum Team' }
          ].map(role => {
            const progress = getProgressByRole(role.id);
            return (
              <div key={role.id}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem', fontSize: '0.9rem' }}>
                  <span className="text-white" style={{ fontWeight: 'bold' }}>{role.name}</span>
                  <span className="text-gold">{progress}%</span>
                </div>
                <div style={{ width: '100%', height: '8px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${progress}%`, background: 'var(--crear-gold)', transition: 'width 0.5s ease-out' }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* LAS 7 PREGUNTAS DEL SO-AR */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: '1.5rem' }}>
        
        {/* P1 & P2 */}
        <div className="glass-panel" style={{ padding: '1.5rem' }}>
          <h3 className="text-blue" style={{ marginTop: 0, fontSize: '1rem', borderBottom: '1px solid rgba(0,212,255,0.2)', paddingBottom: '0.5rem' }}>1. ¿QUÉ ENTRENAMIENTO ESTÁ EN OPERACIÓN?</h3>
          <p className="text-white" style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>{currentTraining}</p>
          
          <h3 className="text-blue" style={{ marginTop: '2rem', fontSize: '1rem', borderBottom: '1px solid rgba(0,212,255,0.2)', paddingBottom: '0.5rem' }}>2. ¿CUÁL ES EL SIGUIENTE ENTRENAMIENTO?</h3>
          <p className="text-white" style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>{nextTraining}</p>
        </div>

        {/* P3 */}
        <div className="glass-panel" style={{ padding: '1.5rem' }}>
          <h3 className="text-gold" style={{ marginTop: 0, fontSize: '1rem', borderBottom: '1px solid rgba(255,215,0,0.2)', paddingBottom: '0.5rem' }}>3. ¿QUÉ DEBE QUEDAR CONFIRMADO ESTA SEMANA?</h3>
          <ul style={{ paddingLeft: '1.2rem', margin: 0, color: 'var(--text-muted)' }}>
            {myPendingTasks.map(t => (
              <li key={t.id} style={{ marginBottom: '0.5rem' }}>
                <span className={t.isCritical ? 'text-white font-bold' : ''}>{t.task || t.title}</span>
              </li>
            ))}
            {myPendingTasks.length === 0 && <li>Ninguna confirmación pendiente para esta fase.</li>}
          </ul>
        </div>

        {/* P4 & P5 */}
        <div className="glass-panel" style={{ padding: '1.5rem', gridColumn: '1 / -1' }}>
          <h3 className="text-blue" style={{ marginTop: 0, fontSize: '1rem', borderBottom: '1px solid rgba(0,212,255,0.2)', paddingBottom: '0.5rem' }}>
            4 y 5. METAS PRINCIPALES Y RESPONSABLES
          </h3>
          {assignedGoals.length === 0 ? (
            <p className="text-muted">No hay metas asignadas activas.</p>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem' }}>
              {assignedGoals.map(g => (
                <div key={g.id} style={{ padding: '1rem', background: 'rgba(255,255,255,0.05)', borderRadius: '8px' }}>
                  <p className="text-white font-bold" style={{ margin: '0 0 0.5rem' }}>{g.task || g.title}</p>
                  <p className="text-muted" style={{ margin: 0, fontSize: '0.85rem' }}><strong>Resp:</strong> {g.role}</p>
                  <p className="text-muted" style={{ margin: 0, fontSize: '0.85rem' }}><strong>Límite:</strong> {g.deadline}</p>
                  <p className="text-muted" style={{ margin: 0, fontSize: '0.85rem' }}><strong>Obj:</strong> {g.expectedResult}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* P6 */}
        <div className="glass-panel" style={{ padding: '1.5rem', border: '1px solid rgba(239, 68, 68, 0.3)' }}>
          <h3 className="text-gold" style={{ color: '#ef4444', marginTop: 0, fontSize: '1rem', borderBottom: '1px solid rgba(239,68,68,0.2)', paddingBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <AlertTriangle size={18} /> 6. ¿QUÉ ESTÁ ATRASADO O EN RIESGO?
          </h3>
          <ul style={{ paddingLeft: '1.2rem', margin: 0, color: 'var(--text-muted)' }}>
            {atRiskTasks.map(t => (
              <li key={t.id} style={{ marginBottom: '0.5rem' }}>
                <strong className="text-white">{t.task || t.title}</strong> <span style={{ fontSize: '0.8rem', color: '#ef4444' }}>({t.role})</span>
              </li>
            ))}
            {atRiskTasks.length === 0 && <li style={{ color: 'var(--color-success)' }}>✅ Todo bajo control. Ningún pendiente rojo.</li>}
          </ul>
        </div>

        {/* P7 */}
        <div className="glass-panel" style={{ padding: '1.5rem' }}>
          <h3 className="text-gold" style={{ marginTop: 0, fontSize: '1rem', borderBottom: '1px solid rgba(255,215,0,0.2)', paddingBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Activity size={18} /> 7. INTERVENCIÓN GERENCIAL REQUERIDA
          </h3>
          <ul style={{ paddingLeft: '1.2rem', margin: 0, color: 'var(--text-muted)' }}>
            {managerIntervention.map(t => (
              <li key={t.id} style={{ marginBottom: '0.5rem' }}>
                <span className="text-white">{t.task || t.title}</span>
              </li>
            ))}
            {managerIntervention.length === 0 && <li>✅ No se requiere intervención crítica hoy.</li>}
          </ul>
        </div>

      </div>
    </div>
  );
}
