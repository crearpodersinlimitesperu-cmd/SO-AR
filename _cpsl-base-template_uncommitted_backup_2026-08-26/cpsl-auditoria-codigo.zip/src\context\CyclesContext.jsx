import { createContext, useContext, useState, useEffect } from 'react';
import { cyclesData } from '../data/cyclesData';

const CyclesContext = createContext();

export function CyclesProvider({ children }) {
  const [currentCycle, setCurrentCycle] = useState(null);
  const [currentStage, setCurrentStage] = useState('PRE-C1');

  useEffect(() => {
    // Para el MVP, tomamos el primer ciclo (o el que corresponda por fecha actual)
    if (cyclesData && cyclesData.length > 0) {
      const cycle = cyclesData[0];
      setCurrentCycle(cycle);

      // Lógica simple para determinar la etapa basada en la fecha de hoy
      const today = new Date();
      const c1Start = new Date(cycle.c1_start);
      const c2Start = new Date(cycle.c2_start);
      const maestriaStart = new Date(cycle.maestria_start);

      if (today < c1Start) {
        setCurrentStage('PRE-C1');
      } else if (today >= c1Start && today < c2Start) {
        setCurrentStage('C1');
      } else if (today >= c2Start && today < maestriaStart) {
        setCurrentStage('C2');
      } else {
        setCurrentStage('MAESTRIA');
      }
    }
  }, []);

  return (
    <CyclesContext.Provider value={{ currentCycle, currentStage }}>
      {children}
    </CyclesContext.Provider>
  );
}

export function useCycles() {
  return useContext(CyclesContext);
}
