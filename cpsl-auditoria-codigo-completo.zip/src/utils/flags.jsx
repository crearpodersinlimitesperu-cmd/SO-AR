export const getFlagForSede = (sede) => {
  if (!sede) return '🌎';
  const s = sede.toLowerCase();

  if (s.includes('ecuador') || s.includes('uio') || s.includes('quito') || s.includes('guayaquil') || s.includes('gye') || s.includes('cuenca') || s.includes('cue')) {
    return '🇪🇨';
  }
  if (s.includes('lima') || s.includes('lim') || s.includes('peru') || s.includes('perú')) {
    return '🇵🇪';
  }
  if (s.includes('colombia') || s.includes('med') || s.includes('medellin') || s.includes('medellín') || s.includes('bogota') || s.includes('bogotá')) {
    return '🇨🇴';
  }
  if (s.includes('mexico') || s.includes('mex') || s.includes('mx') || s.includes('méxico')) {
    return '🇲🇽';
  }
  
  return '🌎'; // Global / Multinacional
};
