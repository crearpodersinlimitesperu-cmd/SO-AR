// src/data/venuesData.js
// Configuración de Sedes, Hoteles y Salones Oficiales por Defecto

export const defaultVenues = {
  Lima: {
    sede: 'Lima',
    c1_venue: 'Hotel José Antonio Deluxe Miraflores (Calle Bellavista 133, Miraflores)',
    c2_venue: 'Hotel José Antonio Deluxe Miraflores (Calle Bellavista 133, Miraflores)',
    mj_venue: 'Hotel José Antonio Deluxe Miraflores (Calle Bellavista 133, Miraflores)',
    viaje_venue: 'Hostal Sol y Luna (Cieneguilla, Lima, Perú)',
    address: 'Calle Bellavista 133, Miraflores, Lima, Perú',
    city: 'Lima',
    country: 'Perú'
  },
  Quito: {
    sede: 'Quito',
    c1_venue: 'Hotel Dann Carlton Quito (Av. República de El Salvador N34-377)',
    c2_venue: 'Hotel Dann Carlton Quito (Av. República de El Salvador N34-377)',
    mj_venue: 'Hotel Dann Carlton Quito (Av. República de El Salvador N34-377)',
    viaje_venue: 'Hostería Papagayo (Cotopaxi / Machachi, Ecuador)',
    address: 'Av. República de El Salvador N34-377, Quito, Ecuador',
    city: 'Quito',
    country: 'Ecuador'
  },
  Cuenca: {
    sede: 'Cuenca',
    c1_venue: 'Hotel Oro Verde Cuenca (Av. Ordóñez Lasso s/n)',
    c2_venue: 'Hotel Oro Verde Cuenca (Av. Ordóñez Lasso s/n)',
    mj_venue: 'Hotel Oro Verde Cuenca (Av. Ordóñez Lasso s/n)',
    viaje_venue: 'Hostería Dos Chorreras (Cajas, Cuenca, Ecuador)',
    address: 'Av. Ordóñez Lasso s/n, Cuenca, Ecuador',
    city: 'Cuenca',
    country: 'Ecuador'
  },
  Guayaquil: {
    sede: 'Guayaquil',
    c1_venue: 'Hotel Wyndham Guayaquil (Puerto Santa Ana)',
    c2_venue: 'Hotel Wyndham Guayaquil (Puerto Santa Ana)',
    mj_venue: 'Hotel Wyndham Guayaquil (Puerto Santa Ana)',
    viaje_venue: 'Hostería D’Franco (Bucay / Guayas, Ecuador)',
    address: 'Calle Numa Pompilio Llona, Puerto Santa Ana, Guayaquil, Ecuador',
    city: 'Guayaquil',
    country: 'Ecuador'
  },
  Medellin: {
    sede: 'Medellín',
    c1_venue: 'Hotel Diez Category El Poblado (Calle 10A #34-11)',
    c2_venue: 'Hotel Diez Category El Poblado (Calle 10A #34-11)',
    mj_venue: 'Hotel Diez Category El Poblado (Calle 10A #34-11)',
    viaje_venue: 'Hostería Llanogrande (Rionegro / Antioquia, Colombia)',
    address: 'Calle 10A #34-11, El Poblado, Medellín, Colombia',
    city: 'Medellín',
    country: 'Colombia'
  },
  Mexico: {
    sede: 'México',
    c1_venue: 'Hotel Galería Plaza Reforma (Hamburgo 195, Juárez)',
    c2_venue: 'Hotel Galería Plaza Reforma (Hamburgo 195, Juárez)',
    mj_venue: 'Hotel Galería Plaza Reforma (Hamburgo 195, Juárez)',
    viaje_venue: 'Hotel Misión Grand Valle de Bravo (Edo. de México)',
    address: 'Hamburgo 195, Juárez, Cuauhtémoc, CDMX, México',
    city: 'Ciudad de México',
    country: 'México'
  }
};

/**
 * Obtiene el lugar/hotel oficial para una sede y nivel de entrenamiento
 */
export function getVenueForTraining(sede, trainingLevel = 'C1', rawPlace = '', rawAddress = '') {
  const normSede = (sede || '').trim().toLowerCase();
  const level = (trainingLevel || '').toUpperCase();
  
  let matchKey = 'Lima';
  if (normSede.includes('lima') || normSede === 'lim' || normSede.includes('pe lim') || normSede === 'pe') matchKey = 'Lima';
  else if (normSede.includes('quito') || normSede === 'uio' || normSede.includes('ec uio')) matchKey = 'Quito';
  else if (normSede.includes('cuenca') || normSede === 'cue' || normSede.includes('ec cue')) matchKey = 'Cuenca';
  else if (normSede.includes('guayaquil') || normSede === 'gye' || normSede.includes('ec gye')) matchKey = 'Guayaquil';
  else if (normSede.includes('medell') || normSede === 'med' || normSede.includes('co med')) matchKey = 'Medellin';
  else if (normSede.includes('mex') || normSede.includes('méx') || normSede.includes('mx')) matchKey = 'Mexico';

  const venueObj = defaultVenues[matchKey] || defaultVenues.Lima;

  // Si el evento es "El Viaje", SIEMPRE devolver por defecto el hostal/lugar de retiro asignado
  if (level.includes('VIAJE') || level.includes('RETIRO') || level.includes('CIE') || level.includes('SOL Y LUNA')) {
    try {
      const customVenues = JSON.parse(localStorage.getItem('cpsl_custom_venues') || '{}');
      if (customVenues[matchKey] && customVenues[matchKey].viaje_venue) {
        return customVenues[matchKey].viaje_venue;
      }
    } catch (e) {}
    return venueObj.viaje_venue || (matchKey === 'Lima' ? 'Hostal Sol y Luna (Cieneguilla, Lima, Perú)' : venueObj.mj_venue);
  }

  // Si viene un nombre específico de hotel con más de 20 caracteres y contiene 'hotel', 'hostal', 'hostería' o 'salón', usarlo
  const cleanPlace = (rawPlace || '').trim();
  const isGeneric = !cleanPlace || 
                    cleanPlace.toLowerCase() === 'lima, perú' || 
                    cleanPlace.toLowerCase() === 'lima, peru' ||
                    cleanPlace.toLowerCase() === 'lima' ||
                    cleanPlace.toLowerCase() === 'quito, ecuador' ||
                    cleanPlace.toLowerCase() === 'quito' ||
                    cleanPlace.toLowerCase() === 'cuenca, ecuador' ||
                    cleanPlace.toLowerCase() === 'cuenca' ||
                    cleanPlace.toLowerCase() === 'guayaquil' ||
                    cleanPlace.toLowerCase() === 'medellín' ||
                    cleanPlace.toLowerCase() === 'medellin' ||
                    cleanPlace.toLowerCase() === 'méxico' ||
                    cleanPlace.toLowerCase() === 'mexico' ||
                    cleanPlace.toLowerCase().includes('pe lim') ||
                    cleanPlace.toLowerCase().includes('por confirmar');

  if (!isGeneric && (cleanPlace.toLowerCase().includes('hotel') || cleanPlace.toLowerCase().includes('hostal') || cleanPlace.toLowerCase().includes('hoster') || cleanPlace.toLowerCase().includes('salon') || cleanPlace.toLowerCase().includes('salón') || cleanPlace.length > 25)) {
    return cleanPlace;
  }

  // Leer overrides personalizados en localStorage si existen
  try {
    const customVenues = JSON.parse(localStorage.getItem('cpsl_custom_venues') || '{}');
    if (customVenues[matchKey]) {
      if ((level.includes('C1') || level.includes('UNO')) && customVenues[matchKey].c1_venue) return customVenues[matchKey].c1_venue;
      if ((level.includes('C2') || level.includes('DOS')) && customVenues[matchKey].c2_venue) return customVenues[matchKey].c2_venue;
      if ((level.includes('MJ') || level.includes('MAESTR') || level.includes('JUEGO')) && customVenues[matchKey].mj_venue) return customVenues[matchKey].mj_venue;
      if (customVenues[matchKey].c1_venue) return customVenues[matchKey].c1_venue;
    }
  } catch (e) {}

  if (level.includes('C2') || level.includes('DOS')) return venueObj.c2_venue;
  if (level.includes('MJ') || level.includes('MAESTR') || level.includes('JUEGO')) return venueObj.mj_venue;
  return venueObj.c1_venue;
}
