export const roles = [
  { id: 'gerente', name: 'Gerente de Sede' },
  { id: 'coord_maestria', name: 'Coordinador/a Maestría (CMJ)' },
  { id: 'coord_c1', name: 'Coordinador/a C1/C2' },
  { id: 'capitan', name: 'Capitán' },
  { id: 'qt', name: 'Equipo de Apoyo' } // Replaced QT
];

// Fases oficiales del SO-AR (Niveles Temporales y Gates)
export const checklistData = [
  // --- GATE T-30 ---
  { 
    id: 't30_presupuesto', role: 'gerente', cyclePhase: 'T-30', task: 'Presupuesto aprobado y fondos separados',
    priority: 'Crítica', deadline: 'T-30', evidence: 'Reporte Financiero', dependency: 'Ninguna', escalation: 'Dirección General', isCritical: true
  },
  { 
    id: 't30_salon', role: 'gerente', cyclePhase: 'T-30', task: 'Salón definido, separado y pagado',
    priority: 'Crítica', deadline: 'T-30', evidence: 'Contrato y Comprobante de Pago', dependency: 'Presupuesto aprobado', escalation: 'Dirección General', isCritical: true
  },
  { 
    id: 't30_entrenador', role: 'gerente', cyclePhase: 'T-30', task: 'Entrenador confirmado',
    priority: 'Crítica', deadline: 'T-30', evidence: 'Correo/Mensaje de confirmación', dependency: 'Ninguna', escalation: 'Dirección General', isCritical: true
  },
  { 
    id: 't30_hotel', role: 'gerente', cyclePhase: 'T-30', task: 'Hotel del entrenador confirmado y pagado',
    priority: 'Crítica', deadline: 'T-30', evidence: 'Comprobante de Reserva/Pago', dependency: 'Entrenador confirmado', escalation: 'Dirección General', isCritical: true
  },
  { 
    id: 't30_vuelo', role: 'gerente', cyclePhase: 'T-30', task: 'Vuelo del entrenador confirmado y pagado',
    priority: 'Crítica', deadline: 'T-30', evidence: 'Boleto Electrónico', dependency: 'Entrenador confirmado', escalation: 'Dirección General', isCritical: true
  },

  // --- GATE T-21 ---
  {
    id: 't21_censo', role: 'coord_c1', cyclePhase: 'T-21', task: 'Censo preliminar de inscritos',
    priority: 'Media', deadline: 'T-21', evidence: 'Listado en CRM', dependency: 'Ninguna', escalation: 'Gerente', isCritical: false
  },

  // --- GATE T-14 ---
  {
    id: 't14_apoyo', role: 'capitan', cyclePhase: 'T-14', task: 'Convocatoria y roles de Equipo de Apoyo confirmados',
    priority: 'Alta', deadline: 'T-14', evidence: 'Lista de Equipo de Apoyo', dependency: 'Ninguna', escalation: 'Gerente', isCritical: true
  },

  // --- GATE T-7 ---
  {
    id: 't7_freeze', role: 'coord_c1', cyclePhase: 'T-7', task: 'Freeze de listas de asistencia iniciales',
    priority: 'Alta', deadline: 'T-7', evidence: 'Lista Exportada', dependency: 'Censo preliminar', escalation: 'Gerente', isCritical: true
  },
  {
    id: 't7_uniformes', role: 'qt', cyclePhase: 'T-7', task: 'Auditoría de uniformes de Equipo de Apoyo',
    priority: 'Media', deadline: 'T-7', evidence: 'Checklist Fotográfico', dependency: 'Asignación Equipo de Apoyo', escalation: 'Capitán', isCritical: false
  },

  // --- OPERACIÓN C1 ---
  {
    id: 'c1_registro', role: 'coord_c1', cyclePhase: 'C1', task: 'Apertura de registro y resguardo de pertenencias',
    priority: 'Crítica', deadline: 'DÍA 0 (Viernes)', evidence: 'Planillas de Ingreso', dependency: 'Listas Freeze', escalation: 'Gerente', isCritical: true
  },
  {
    id: 'c1_contencion', role: 'qt', cyclePhase: 'C1', task: 'Mantenimiento hermético de sala y contención silenciosa',
    priority: 'Alta', deadline: 'DÍA 0', evidence: 'Ninguna', dependency: 'Sala instalada', escalation: 'Capitán', isCritical: true
  },

  // --- CIERRE C1 ---
  {
    id: 'postc1_devolucion', role: 'qt', cyclePhase: 'POST-C1', task: 'Devolución del salón en estado impecable',
    priority: 'Media', deadline: 'T+1 (Domingo)', evidence: 'Acta de entrega / Fotos', dependency: 'Ninguna', escalation: 'Capitán', isCritical: false
  },
  {
    id: 'postc1_rezagados', role: 'coord_c1', cyclePhase: 'POST-C1', task: 'Reporte final de asistencia y Rezagados',
    priority: 'Crítica', deadline: 'T+1 (Domingo Noche)', evidence: 'Reporte Financiero', dependency: 'Cierre de C1', escalation: 'Gerente', isCritical: true
  },

  // --- OPERACIÓN C2 ---
  {
    id: 'c2_grounding', role: 'coord_c1', cyclePhase: 'C2', task: 'Arranque y grounding del equipo',
    priority: 'Alta', deadline: 'DÍA 0 (Jueves)', evidence: 'Foto de Grounding', dependency: 'Ninguna', escalation: 'Gerente', isCritical: true
  },
  {
    id: 'c2_mesas', role: 'coord_c1', cyclePhase: 'C2', task: 'Operación de mesas de enrolamiento a MJ',
    priority: 'Crítica', deadline: 'DÍA 0 (Sábado/Domingo)', evidence: 'Vouchers/Registros', dependency: 'Ninguna', escalation: 'Gerente', isCritical: true
  },

  // --- GATE VIERNES C2 ---
  {
    id: 'gatec2_grounding', role: 'coord_maestria', cyclePhase: 'C2', task: 'Groundings de los tres FDS de MJ confirmados',
    priority: 'Crítica', deadline: 'Viernes C2', evidence: 'Documento Firmado', dependency: 'Managers Confirmados', escalation: 'Gerente', isCritical: true
  },
  {
    id: 'gatec2_rezagados', role: 'coord_c1', cyclePhase: 'C2', task: 'Meta de Rezagados de C1 comunicada y responsable asignado',
    priority: 'Crítica', deadline: 'Viernes C2', evidence: 'Meta en CRM/Sistema', dependency: 'Reporte Rezagados C1', escalation: 'Gerente', isCritical: true
  },

  // --- PREPARACIÓN MJ ---
  {
    id: 'premj_managers', role: 'coord_maestria', cyclePhase: 'PRE-MJ', task: 'Relación 1 Manager por cada 6 Participantes configurada',
    priority: 'Crítica', deadline: 'Semana 1', evidence: 'Lista de Asignación', dependency: 'Graduados C2', escalation: 'Gerente', isCritical: true
  },
  {
    id: 'premj_entrenador', role: 'coord_maestria', cyclePhase: 'PRE-MJ', task: 'Agenda de Entrenador MJ bloqueada',
    priority: 'Alta', deadline: 'Jueves Pre-FDS', evidence: 'Captura Google Calendar', dependency: 'Ninguna', escalation: 'Gerente', isCritical: true
  },

  // --- OPERACIÓN MJ ---
  {
    id: 'mj_registro', role: 'coord_maestria', cyclePhase: 'MJ', task: 'Registro estricto (Sin firmas de reglas no hay ingreso)',
    priority: 'Crítica', deadline: 'Viernes FDS 1', evidence: 'Actas Firmadas', dependency: 'Ninguna', escalation: 'Gerente', isCritical: true
  },
  {
    id: 'mj_imposibles', role: 'coord_maestria', cyclePhase: 'MJ', task: 'Seguimiento de Futuros Imposibles',
    priority: 'Media', deadline: 'Lunes post-FDS', evidence: 'Reporte a Entrenador', dependency: 'Ejecución FDS', escalation: 'Ninguno', isCritical: false
  },

  // --- CIERRE MJ ---
  {
    id: 'cierre_mj_oro', role: 'coord_maestria', cyclePhase: 'POST-MJ', task: 'Certificación de Cierre de Oro',
    priority: 'Crítica', deadline: 'T+7', evidence: 'Acta de Dirección', dependency: 'Graduación', escalation: 'Gerente', isCritical: true
  }
];

export const getTasksByRole = (roleId) => checklistData.filter(t => t.role === roleId);
