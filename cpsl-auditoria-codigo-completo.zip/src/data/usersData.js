export const normalizeRole = (role) => {
  if (!role) return 'miembro';
  const r = role.toLowerCase().trim();
  if (r === 'coordinador_c1c2' || r === 'coord_c1' || r === 'coordinador_c1') return 'coord_c1';
  if (r === 'coordinador_mj' || r === 'coord_maestria' || r === 'coordinador_maestria') return 'coord_maestria';
  if (r === 'gerente' || r === 'gerente_sede') return 'gerente';
  if (r === 'capitan' || r === 'capitán') return 'capitan';
  if (r === 'qt' || r === 'quantum_team' || r === 'quantum team' || r === 'quantum') return 'qt';
  if (r === 'director_maestria' || r === 'director_mj') return 'director_maestria';
  if (r === 'manager' || r === 'managers') return 'manager';
  if (r === 'cfo') return 'cfo';
  return r;
};

export const normalizeSede = (sede) => {
  if (!sede) return 'Sede Global';
  const s = sede.trim();
  if (s === 'MED' || s.toLowerCase().includes('medell')) return 'Medellín';
  if (s === 'LIM' || s.toLowerCase().includes('lima')) return 'Lima';
  if (s === 'CUE' || s.toLowerCase().includes('cuenca')) return 'Cuenca';
  if (s === 'GYE' || s.toLowerCase().includes('guayaquil')) return 'Guayaquil';
  if (s === 'MEX' || s.toLowerCase().includes('mex')) return 'México';
  if (s === 'UIO-C1' || s.toLowerCase().includes('ciclo 1') || s.toLowerCase().includes('ciclo1')) return 'Quito Ciclo 1';
  if (s === 'UIO-C2' || s.toLowerCase().includes('ciclo 2') || s.toLowerCase().includes('ciclo2')) return 'Quito Ciclo 2';
  if (s === 'UIO' || s.toLowerCase().includes('quito')) return 'Quito Ciclo 1';
  if (s.toLowerCase().includes('global')) return 'Sede Global';
  return s;
};

export const OPERATIONAL_SEDES = [
  'Lima',
  'Quito Ciclo 1',
  'Quito Ciclo 2',
  'Cuenca',
  'Guayaquil',
  'Medellín',
  'México'
];

export const ROLE_DISPLAY_NAMES = {
  coord_c1: 'Coordinador C1 / C2',
  coordinador_c1c2: 'Coordinador C1 / C2',
  coord_maestria: 'Coordinador Maestría (MJ)',
  coordinador_mj: 'Coordinador Maestría (MJ)',
  gerente: 'Gerente de Sede',
  capitan: 'Capitán de Sede',
  qt: 'Quantum Team (QT)',
  director_maestria: 'Director de Maestría',
  manager: 'Manager',
  cfo: 'CFO (Chief Financial Officer)',
  direccion: 'Dirección Global',
  finanzas: 'Finanzas',
  coordinador: 'Coordinación Administrativa',
  talento_humano: 'Talento Humano',
  legal: 'Legal / Jurídico'
};

/**
 * Busca un usuario por cualquiera de sus correos (corporativo @crearpsl.net o personal Gmail)
 */
export const findUserByAnyEmail = (searchEmail) => {
  if (!searchEmail) return null;
  const emailLower = searchEmail.toLowerCase().trim();
  return usersData.find(u => {
    if (u.email?.toLowerCase().trim() === emailLower) return true;
    if (u.corporateEmail?.toLowerCase().trim() === emailLower) return true;
    if (u.personalEmail?.toLowerCase().trim() === emailLower) return true;
    if (u.emails && u.emails.some(e => e.toLowerCase().trim() === emailLower)) return true;
    return false;
  }) || null;
};

export const usersData = [];
