import { createContext, useContext, useState, useEffect } from 'react';
import { cyclesData } from '../data/cyclesData';

const CyclesContext = createContext();

export function CyclesProvider({ children }) {
  const [currentCycle, setCurrentCycle] = useState(null);
  const [currentStage, setCurrentStage] = useState('PRE-C1');

  useEffect(() => {
    if (cyclesData && cyclesData.length > 0) {
      const today = new Date();
      
      // Buscar el ciclo activo correspondiente a la fecha de hoy (N9)
      let active = cyclesData.find(c => {
        const startWindow = new Date(c.c1_start);
        startWindow.setDate(startWindow.getDate() - 40); // Incluye GATE 1
        const endWindow = new Date(c.maestria_end || c.maestria_start);
        endWindow.setDate(endWindow.getDate() + 20); // Incluye POST-MJ
        return today >= startWindow && today <= endWindow;
      });

      if (!active) {
        // Fallback al ciclo más próximo
        active = cyclesData[0];
      }

      setCurrentCycle(active);

      // Determinación precisa de la etapa operativa SO-AR
      const c1Start = new Date(active.c1_start);
      const c1End = new Date(active.c1_end || active.c1_start);
      c1End.setHours(23, 59, 59);

      const c2Start = new Date(active.c2_start);
      const c2End = new Date(active.c2_end || active.c2_start);
      c2End.setHours(23, 59, 59);

      const maestriaStart = new Date(active.maestria_start);
      const maestriaEnd = new Date(active.maestria_end || active.maestria_start);
      maestriaEnd.setHours(23, 59, 59);

      const gate1Date = new Date(active.c1_start);
      gate1Date.setDate(gate1Date.getDate() - 21);

      if (today < gate1Date) {
        setCurrentStage('GATE 1');
      } else if (today < c1Start) {
        setCurrentStage('PRE-C1');
      } else if (today >= c1Start && today <= c1End) {
        setCurrentStage('C1');
      } else if (today > c1End && today < c2Start) {
        setCurrentStage('POST-C1');
      } else if (today >= c2Start && today <= c2End) {
        setCurrentStage('C2');
      } else if (today > c2End && today < maestriaStart) {
        setCurrentStage('PRE-MJ');
      } else if (today >= maestriaStart && today <= maestriaEnd) {
        setCurrentStage('MJ');
      } else {
        setCurrentStage('POST-MJ');
      }
    }
  }, []);

  return (
    <CyclesContext.Provider value={{ currentCycle, currentStage }}>
      {children}
    </CyclesContext.Provider>
  );
}

export function useCycles() {
  return useContext(CyclesContext);
}
