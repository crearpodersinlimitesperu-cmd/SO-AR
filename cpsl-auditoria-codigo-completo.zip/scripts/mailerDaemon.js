require('dotenv').config();
const nodemailer = require('nodemailer');
const sanitizeHtml = require('sanitize-html');
const { initializeApp } = require('firebase/app');
const { getFirestore, collection, onSnapshot, doc, updateDoc, query, where, getDocs } = require('firebase/firestore');

// --- 1. CONFIGURACIÓN DE FIREBASE CLIENT ---
// NOTA: Para ejecutar esto necesitas "npm install nodemailer firebase dotenv"
// Reemplaza esto con los datos de tu src/services/firebase.js
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_AUTH_DOMAIN",
  projectId: "TU_PROJECT_ID",
  storageBucket: "TU_STORAGE_BUCKET",
  messagingSenderId: "TU_SENDER_ID",
  appId: "TU_APP_ID"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// --- 2. CONFIGURACIÓN DE GMAIL (NODEMAILER) ---
if (!process.env.GMAIL_USER || !process.env.GMAIL_PASS) {
  console.error("❌ Faltan credenciales de Gmail (GMAIL_USER o GMAIL_PASS). El daemon no puede iniciar.");
  process.exit(1);
}

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS
  }
});

console.log("🚀 Mailer Daemon Iniciado. Escuchando nuevos correos en Firestore...");

// --- 3. ESCUCHAR LA COLECCIÓN 'mail' ---
onSnapshot(collection(db, 'mail'), (snapshot) => {
  snapshot.docChanges().forEach(async (change) => {
    if (change.type === 'added') {
      const data = change.doc.data();
      
      // Si el correo ya tiene estado (como SUCCESS), ignorarlo
      if (data.delivery && data.delivery.state) return;

      const isCorporate = ['@crearpsl.net', '@crearpsl.com'].some(d => data.to?.toLowerCase().endsWith(d));
      
      if (!isCorporate) {
        // Para correos externos (gmail, hotmail, etc.), verificar que existan en el directorio
        try {
          const q = query(collection(db, "users"), where("emails", "array-contains", data.to?.toLowerCase().trim()));
          const snap = await getDocs(q);
          if (snap.empty) {
            console.warn(`⚠️ Intento de envío a correo no registrado en el directorio: ${data.to}`);
            await updateDoc(doc(db, 'mail', change.doc.id), { 
              'delivery.state': 'REJECTED', 
              reason: 'Correo externo no pertenece a ningún usuario registrado' 
            });
            return;
          }
        } catch (error) {
          console.error("Error validando correo contra la base de datos:", error);
          // Si hay error validando, rechazamos por seguridad
          return;
        }
      }

      console.log(`📧 Nuevo correo detectado para: ${data.to}`);

      const rawHtml = data.message?.html || '<p>Tienes una notificación.</p>';
      const cleanHtml = sanitizeHtml(rawHtml, {
        allowedTags: sanitizeHtml.defaults.allowedTags.concat(['img', 'h1', 'h2']),
        allowedAttributes: {
          ...sanitizeHtml.defaults.allowedAttributes,
          'a': ['href', 'name', 'target'],
          'img': ['src', 'alt']
        }
      });

      const mailOptions = {
        from: '"CREAR Poder Sin Límites" <servidorcrearpsl@gmail.com>',
        to: data.to,
        subject: data.message?.subject || 'Notificación SO-AR',
        html: cleanHtml
      };

      try {
        await transporter.sendMail(mailOptions);
        console.log(`✅ Correo enviado a ${data.to}`);
        
        // Marcar como enviado en Firestore
        await updateDoc(doc(db, 'mail', change.doc.id), {
          'delivery.state': 'SUCCESS',
          'delivery.endTime': new Date().toISOString()
        });
      } catch (error) {
        console.error(`❌ Error al enviar a ${data.to}:`, error);
        await updateDoc(doc(db, 'mail', change.doc.id), {
          'delivery.state': 'ERROR',
          'delivery.error': error.message
        });
      }
    }
  });
});
